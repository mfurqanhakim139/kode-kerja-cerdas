# Percabangan berdasarkan nama
nama = input("Masukkan nama: ")

if nama == "Budi":
    print("Halo Budi!")
elif nama == "Citra":
    print("Hai Citra!")
else:
    print("Halo orang asing!")
