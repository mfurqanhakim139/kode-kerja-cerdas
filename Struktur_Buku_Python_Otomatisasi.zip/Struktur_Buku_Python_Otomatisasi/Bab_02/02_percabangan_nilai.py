# Percabangan berdasarkan nilai
nilai = int(input("Masukkan nilai ujian: "))
if nilai >= 80:
    print("Nilai Anda A")
elif nilai >= 70:
    print("Nilai Anda B")
elif nilai >= 60:
    print("Nilai Anda C")
else:
    print("Anda perlu belajar lagi.")
6