# Contoh while sederhana
angka = 0
while angka < 5:
    print("Angka saat ini:", angka)
    angka = angka + 1 # Penting: Ubah variabel agar kondisi bisa False

print("Perulangan while selesai.")

