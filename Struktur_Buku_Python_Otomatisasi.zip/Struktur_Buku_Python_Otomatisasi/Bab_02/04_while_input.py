# Contoh while dengan input pengguna
nama = ""
while nama != "selesai":
    nama = input("Masukkan nama (ketik 'selesai' untuk berhenti): ")
    if nama != "selesai":
        print("Halo,", nama)

