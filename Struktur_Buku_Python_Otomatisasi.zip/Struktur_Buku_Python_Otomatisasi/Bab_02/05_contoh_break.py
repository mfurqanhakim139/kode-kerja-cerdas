while True: # Loop potensial tak terbatas
    nama = input("Siapa nama Anda? (ketik 'stop' untuk keluar): ")
    if nama == 'stop':
        break # Keluar dari loop jika input 'stop'
    print("Halo", nama)
print("Program berhenti.")
