print("Hitung maju:")
for i in range(5): # i akan bernilai 0, 1, 2, 3, 4
    print(i)

print("\nHitung dari 5 sampai 9:")
for i in range(5, 10): # i akan bernilai 5, 6, 7, 8, 9
    print(i)

print("\nHitung mundur kelipatan 2:")
for i in range(10, 0, -2): # i akan bernilai 10, 8, 6, 4, 2
    print(i)

# Contoh menghitung total
total = 0
for i in range(1, 6): # i = 1, 2, 3, 4, 5
    total = total + i
print("\nTotal dari 1 sampai 5 adalah:", total)
