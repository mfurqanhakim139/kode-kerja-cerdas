import random # Impor modul random

for i in range(5):
    angka_acak = random.randint(1, 10) # Panggil fungsi randint dari modul random
    print("Angka acak:", angka_acak)
