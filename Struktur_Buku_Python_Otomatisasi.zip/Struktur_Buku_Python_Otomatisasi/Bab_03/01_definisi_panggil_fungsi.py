def sapa_dunia():
    print("Halo Dunia Pemrograman!")
    print("Selamat belajar fungsi.")

# Memanggil fungsi
print("Memanggil sapa_dunia pertama kali:")
sapa_dunia()
print("\nMemanggil sapa_dunia lagi:")
sapa_dunia() # Bisa dipanggil berkali-kali
