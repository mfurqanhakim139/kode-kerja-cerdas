print("Baris pertama\nBaris kedua")
print("Kolom1\tKolom2")
print('Dia berkata, "Halo!"') # Kutip berbeda bisa langsung
print("Dia berkata, \"Halo!\"") # Escape kutip ganda
print("Path Windows: C:\\Users\\Nama") # Escape backslash

# Raw string
print(r"Ini adalah raw string, \n dan \t tidak dianggap spesial.")
